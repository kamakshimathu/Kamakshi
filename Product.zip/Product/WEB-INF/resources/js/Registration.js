/**
 * 
 */
function myFunction(t) {
	if (t.is(':checked')) {
		var valueToCopy = $("#copyFrom").val();
		var valueToCopy1 = $("#copyFrom1").val();
		var valueToCopy2 = $("#copyFrom2").val();
		var valueToCopy3 = $("#copyFrom3").val();
		var valueToCopy4 = $("#copyFrom4").val();
		var valueToCopy5 = $("#copyFrom5").val();
		$("#pasteTo").val(valueToCopy);
		$("#pasteTo1").val(valueToCopy1);
		$("#pasteTo2").val(valueToCopy2);
		$("#pasteTo3").val(valueToCopy3);
		$("#pasteTo4").val(valueToCopy4);
		$("#pasteTo5").val(valueToCopy5);
	}
}