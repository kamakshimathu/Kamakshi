/**
 * 
 */
var myapp = angular.module("myapp", []).controller(
		"productController",
		function($scope, $http) {

			$scope.getProductList = function() {
				$http.get('http://localhost:8017/Product/getProductList')
						.success(function(data) {
							$scope.products = data;
						})
			}
			$scope.getCustomerList = function() {
				$http.get('http://localhost:8017/Product/getCustomerList')
						.success(function(data) {
							$scope.customers = data;
						})
			}

			$scope.addToCart = function(productId) {
				$http.put(
						'http://localhost:8017/Product/cart/add/{productId}'
								+ isbn).success(function() {
					alert('Added Successfully');
				})
			}
			$scope.refreshCart = function() {
				$http.get(
						'http://localhost:8017/Product/cart/getCart/'
								+ $scope.cartId).success(function(data) {
					$scope.cart = data;
				})
			}
			$scope.getCart = function(cartId) {
				$scope.cartId = cartId;
				$scope.refreshCart(cartId);
			}

			$scope.removeFromCart = function(cartItemId) {
				$http.put(
						'http://localhost:8017/Product/cart/removecartitem/'
								+ cartItemId).success(function() {
					$scope.refreshCart();
				})
			}

			$scope.clearCart = function() {
				$http.put(
						'http://localhost:8017/Product/cart/removeAllItems/'
								+ $scope.cartId).success(function() {
					$scope.refreshCart();
				});
			}

			$scope.calculateGrandTotal = function() {
				var grandTotal = 0.0
				for (var i = 0; i < $scope.cart.cartItem.length; i++)
					grandTotal = grandTotal + $scope.cart.cartItem[i].price;
				return grandTotal;
			}

		});
